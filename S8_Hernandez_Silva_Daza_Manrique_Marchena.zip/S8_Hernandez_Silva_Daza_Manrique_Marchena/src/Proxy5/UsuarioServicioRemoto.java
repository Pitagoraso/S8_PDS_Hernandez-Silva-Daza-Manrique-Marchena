package Proxy5;

public class UsuarioServicioRemoto implements UsuarioServicio {
    public String obtenerUsuario(int id) {
        return "Usuario" + id;
    }
}
