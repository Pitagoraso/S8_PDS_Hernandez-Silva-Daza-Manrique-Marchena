package Proxy5;

public interface UsuarioServicio {
    String obtenerUsuario(int id);
}
