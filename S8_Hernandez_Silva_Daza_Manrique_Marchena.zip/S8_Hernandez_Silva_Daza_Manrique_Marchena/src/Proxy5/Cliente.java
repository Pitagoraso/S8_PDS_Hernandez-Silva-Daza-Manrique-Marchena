package Proxy5;

public class Cliente {
    public static void main(String[] args) {
        UsuarioServicio usuarioServicio = new ProxyUsuarioServicio();
        System.out.println(usuarioServicio.obtenerUsuario(1));
        System.out.println(usuarioServicio.obtenerUsuario(2));
    }
}
