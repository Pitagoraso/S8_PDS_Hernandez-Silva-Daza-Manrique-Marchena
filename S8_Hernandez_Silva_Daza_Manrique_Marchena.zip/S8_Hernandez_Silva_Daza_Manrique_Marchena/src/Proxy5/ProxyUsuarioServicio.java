package Proxy5;

public class ProxyUsuarioServicio implements UsuarioServicio {
    private UsuarioServicioRemoto usuarioServicioRemoto;


    public String obtenerUsuario(int id) {
        if (usuarioServicioRemoto == null) {
            usuarioServicioRemoto = new UsuarioServicioRemoto();
        }
        System.out.println("Llamando al servicio remoto para obtener usuario con ID: " + id);
        return usuarioServicioRemoto.obtenerUsuario(id);
    }
}
