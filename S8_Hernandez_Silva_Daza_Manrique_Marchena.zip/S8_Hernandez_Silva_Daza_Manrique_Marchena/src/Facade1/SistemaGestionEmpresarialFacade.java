package Facade1;

public class SistemaGestionEmpresarialFacade {
    private Contabilidad contabilidad;
    private Inventario inventario;
    private RecursosHumanos recursosHumanos;

    public SistemaGestionEmpresarialFacade() {
        this.contabilidad = new Contabilidad();
        this.inventario = new Inventario();
        this.recursosHumanos = new RecursosHumanos();
    }

    public void registrarNuevaTransaccion(String detalles) {
        contabilidad.registrarTransaccion(detalles);
    }

    public void actualizarInventario(String item, int cantidad) {
        inventario.actualizarInventario(item, cantidad);
    }

    public void registrarNuevoEmpleado(String nombre) {
        recursosHumanos.registrarEmpleado(nombre);
    }

    public void mostrarEstado() {
        System.out.println("\nEstado del Sistema de Gestion Empresarial:");
        contabilidad.mostrarTransacciones();
        inventario.mostrarInventario();
        recursosHumanos.mostrarEmpleados();
    }
}
