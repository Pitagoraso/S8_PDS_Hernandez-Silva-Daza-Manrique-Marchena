package Facade1;

import java.util.HashMap;
import java.util.Map;

public class Inventario {
    private Map<String, Integer> inventario;

    public Inventario() {
        this.inventario = new HashMap<>();
    }

    public void actualizarInventario(String item, int cantidad) {
        inventario.put(item, inventario.getOrDefault(item, 0) + cantidad);
        System.out.println("Inventario actualizado: " + item + " - " + cantidad);
    }

    public void mostrarInventario() {
        System.out.println("Estado actual del inventario:");
        for (Map.Entry<String, Integer> entry : inventario.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
