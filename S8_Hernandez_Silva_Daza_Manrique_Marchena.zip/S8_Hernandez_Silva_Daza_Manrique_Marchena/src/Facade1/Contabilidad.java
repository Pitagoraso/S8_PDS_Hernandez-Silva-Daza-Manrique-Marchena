package Facade1;

import java.util.ArrayList;
import java.util.List;

public class Contabilidad {
    private List<String> transacciones;

    public Contabilidad() {
        this.transacciones = new ArrayList<>();
    }

    public void registrarTransaccion(String detalles) {
        transacciones.add(detalles);
        System.out.println("Transaccion registrada en contabilidad: " + detalles);
    }

    public void mostrarTransacciones() {
        System.out.println("Transacciones registradas:");
        for (String transaccion : transacciones) {
            System.out.println(transaccion);
        }
    }
}
