package Facade1;

import java.util.ArrayList;
import java.util.List;

public class RecursosHumanos {
    private List<String> empleados;

    public RecursosHumanos() {
        this.empleados = new ArrayList<>();
    }

    public void registrarEmpleado(String nombre) {
        empleados.add(nombre);
        System.out.println("Empleado registrado en recursos humanos: " + nombre);
    }

    public void mostrarEmpleados() {
        System.out.println("Empleados registrados:");
        for (String empleado : empleados) {
            System.out.println(empleado);
        }
    }
}
