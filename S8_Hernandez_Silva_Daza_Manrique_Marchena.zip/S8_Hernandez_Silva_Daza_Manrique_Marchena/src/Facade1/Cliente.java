package Facade1;

public class Cliente {
    public static void main(String[] args) {
        SistemaGestionEmpresarialFacade sistema = new SistemaGestionEmpresarialFacade();

        sistema.registrarNuevaTransaccion("Compra de suministros por $500");
        sistema.actualizarInventario("Sillas", 50);
        sistema.registrarNuevoEmpleado("Juan Perez");

        sistema.mostrarEstado();
    }
}
