package Facade5;

public class XMLConfiguracion {
    public String leerConfiguracion() {
        System.out.println("Leyendo configuracion desde archivo XML");
        return "<configuracion>...</configuracion>";
    }

    public void escribirConfiguracion(String config) {
        System.out.println("Escribiendo configuracion en archivo XML: " + config);
    }
}
