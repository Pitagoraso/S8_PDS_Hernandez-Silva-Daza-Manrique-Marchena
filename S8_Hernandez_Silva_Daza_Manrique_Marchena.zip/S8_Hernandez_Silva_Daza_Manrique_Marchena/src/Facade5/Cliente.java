package Facade5;

public class Cliente {
    public static void main(String[] args) {
        ConfiguracionFacade configFacade = new ConfiguracionFacade();

        String configXML = configFacade.leerConfiguracion("xml");
        System.out.println("Configuracion leida: " + configXML);

        configFacade.escribirConfiguracion("xml", "<configuracion>nueva</configuracion>");

        String configJSON = configFacade.leerConfiguracion("json");
        System.out.println("Configuracion leida: " + configJSON);

        configFacade.escribirConfiguracion("json", "{ \"configuracion\": \"nueva\" }");

        String configDB = configFacade.leerConfiguracion("db");
        System.out.println("Configuracion leida: " + configDB);

        configFacade.escribirConfiguracion("db", "configuracion=nueva");
    }
}
