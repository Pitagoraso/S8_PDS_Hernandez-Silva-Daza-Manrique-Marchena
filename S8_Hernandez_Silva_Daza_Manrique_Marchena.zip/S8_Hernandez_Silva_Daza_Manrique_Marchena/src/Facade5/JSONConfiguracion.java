package Facade5;

public class JSONConfiguracion {
    public String leerConfiguracion() {
        System.out.println("Leyendo configuracion desde archivo JSON");
        return "{ \"configuracion\": ... }";
    }

    public void escribirConfiguracion(String config) {
        System.out.println("Escribiendo configuracion en archivo JSON: " + config);
    }
}
