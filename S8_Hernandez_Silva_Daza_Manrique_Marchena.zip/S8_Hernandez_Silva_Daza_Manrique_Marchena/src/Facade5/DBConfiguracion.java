package Facade5;

public class DBConfiguracion {
    public String leerConfiguracion() {
        System.out.println("Leyendo configuracion desde base de datos");
        return "configuracion=...";
    }

    public void escribirConfiguracion(String config) {
        System.out.println("Escribiendo configuracion en base de datos: " + config);
    }
}
