package Facade5;

public class ConfiguracionFacade {
    private XMLConfiguracion xmlConfig;
    private JSONConfiguracion jsonConfig;
    private DBConfiguracion dbConfig;

    public ConfiguracionFacade() {
        this.xmlConfig = new XMLConfiguracion();
        this.jsonConfig = new JSONConfiguracion();
        this.dbConfig = new DBConfiguracion();
    }

    public String leerConfiguracion(String formato) {
        switch (formato.toLowerCase()) {
            case "xml":
                return xmlConfig.leerConfiguracion();
            case "json":
                return jsonConfig.leerConfiguracion();
            case "db":
                return dbConfig.leerConfiguracion();
            default:
                throw new IllegalArgumentException("Formato no soportado: " + formato);
        }
    }

    public void escribirConfiguracion(String formato, String config) {
        switch (formato.toLowerCase()) {
            case "xml":
                xmlConfig.escribirConfiguracion(config);
                break;
            case "json":
                jsonConfig.escribirConfiguracion(config);
                break;
            case "db":
                dbConfig.escribirConfiguracion(config);
                break;
            default:
                throw new IllegalArgumentException("Formato no soportado: " + formato);
        }
    }
}
