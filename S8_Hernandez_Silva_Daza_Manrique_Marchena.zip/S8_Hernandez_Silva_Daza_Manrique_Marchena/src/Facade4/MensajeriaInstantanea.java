package Facade4;

public class MensajeriaInstantanea {
    public void enviarMensaje(String mensaje) {
        System.out.println("Enviando mensaje instantaneo: " + mensaje);
    }
}
