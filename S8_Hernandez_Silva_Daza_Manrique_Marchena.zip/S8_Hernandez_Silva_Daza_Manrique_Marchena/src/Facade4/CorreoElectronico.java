package Facade4;

public class CorreoElectronico {
    public void enviarMensaje(String mensaje) {
        System.out.println("Enviando correo electronico: " + mensaje);
    }
}
