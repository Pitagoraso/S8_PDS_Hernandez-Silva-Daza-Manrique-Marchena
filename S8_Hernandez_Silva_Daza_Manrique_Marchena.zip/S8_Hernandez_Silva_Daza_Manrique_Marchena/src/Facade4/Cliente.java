package Facade4;

public class Cliente {
    public static void main(String[] args) {
        SistemaMensajeriaFacade sistemaMensajeria = new SistemaMensajeriaFacade();

        sistemaMensajeria.enviarSMS("Hola, este es un SMS!");
        sistemaMensajeria.enviarCorreo("Hola, este es un correo electronico!");
        sistemaMensajeria.enviarMensajeInstantaneo("Hola, este es un mensaje instantaneo!");
    }
}
