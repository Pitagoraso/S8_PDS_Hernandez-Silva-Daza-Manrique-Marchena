package Facade4;

public class SistemaMensajeriaFacade {
    private SMS sms;
    private CorreoElectronico correo;
    private MensajeriaInstantanea mensajeria;

    public SistemaMensajeriaFacade() {
        this.sms = new SMS();
        this.correo = new CorreoElectronico();
        this.mensajeria = new MensajeriaInstantanea();
    }

    public void enviarSMS(String mensaje) {
        sms.enviarMensaje(mensaje);
    }

    public void enviarCorreo(String mensaje) {
        correo.enviarMensaje(mensaje);
    }

    public void enviarMensajeInstantaneo(String mensaje) {
        mensajeria.enviarMensaje(mensaje);
    }
}
