package Facade2;

public class SistemaHogarInteligenteFacade {
    private Luz luz;
    private Termostato termostato;
    private CamaraSeguridad camaraSeguridad;

    public SistemaHogarInteligenteFacade() {
        this.luz = new Luz();
        this.termostato = new Termostato();
        this.camaraSeguridad = new CamaraSeguridad();
    }

    public void encenderLuz() {
        luz.encender();
    }

    public void apagarLuz() {
        luz.apagar();
    }

    public void ajustarTemperatura(int grados) {
        termostato.setTemperatura(grados);
    }

    public void activarCamara() {
        camaraSeguridad.activar();
    }

    public void desactivarCamara() {
        camaraSeguridad.desactivar();
    }
}
