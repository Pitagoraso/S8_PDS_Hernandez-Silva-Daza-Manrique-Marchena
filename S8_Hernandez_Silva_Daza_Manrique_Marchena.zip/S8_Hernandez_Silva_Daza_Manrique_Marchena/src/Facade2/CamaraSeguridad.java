package Facade2;

public class CamaraSeguridad {
    public void activar() {
        System.out.println("Camara de seguridad activada");
    }

    public void desactivar() {
        System.out.println("Camara de seguridad desactivada");
    }
}
