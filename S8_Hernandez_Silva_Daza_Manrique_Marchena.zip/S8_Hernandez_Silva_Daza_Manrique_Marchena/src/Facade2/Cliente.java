package Facade2;

public class Cliente {
    public static void main(String[] args) {
        SistemaHogarInteligenteFacade sistema = new SistemaHogarInteligenteFacade();

        sistema.encenderLuz();
        sistema.ajustarTemperatura(22);
        sistema.activarCamara();
        sistema.apagarLuz();
        sistema.desactivarCamara();
    }
}
