package Facade2;

public class Termostato {
    public void setTemperatura(int grados) {
        System.out.println("Temperatura ajustada a " + grados + " grados");
    }
}
