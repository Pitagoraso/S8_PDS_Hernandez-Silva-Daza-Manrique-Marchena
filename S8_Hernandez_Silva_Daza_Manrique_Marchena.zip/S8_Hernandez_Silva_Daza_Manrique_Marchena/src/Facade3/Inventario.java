package Facade3;

public class Inventario {
    public void agregarProducto(String producto) {
        System.out.println("Producto agregado al inventario: " + producto);
    }

    public void eliminarProducto(String producto) {
        System.out.println("Producto eliminado del inventario: " + producto);
    }

    public void mostrarInventario() {
        System.out.println("Mostrando inventario...");
    }
}
