package Facade3;

public class Pedidos {
    public void crearPedido(String producto) {
        System.out.println("Pedido creado para: " + producto);
    }

    public void cancelarPedido(String producto) {
        System.out.println("Pedido cancelado para: " + producto);
    }

    public void mostrarPedidos() {
        System.out.println("Mostrando pedidos...");
    }
}
