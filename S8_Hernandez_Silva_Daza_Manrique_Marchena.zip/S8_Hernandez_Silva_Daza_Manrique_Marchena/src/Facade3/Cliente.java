package Facade3;

public class Cliente {
    public static void main(String[] args) {
        SistemaGestionVentasFacade sistema = new SistemaGestionVentasFacade();

        sistema.agregarProductoAlInventario("Laptop");
        sistema.agregarCliente("Juan Perez");
        sistema.crearPedido("Laptop");

        sistema.mostrarSistema();

        sistema.cancelarPedido("Laptop");
        sistema.eliminarProductoDelInventario("Laptop");
        sistema.eliminarCliente("Juan Perez");

        sistema.mostrarSistema();
    }
}
