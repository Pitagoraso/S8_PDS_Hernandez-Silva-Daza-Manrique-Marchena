package Facade3;

public class Clientes {
    public void agregarCliente(String cliente) {
        System.out.println("Cliente agregado: " + cliente);
    }

    public void eliminarCliente(String cliente) {
        System.out.println("Cliente eliminado: " + cliente);
    }

    public void mostrarClientes() {
        System.out.println("Mostrando clientes...");
    }
}
