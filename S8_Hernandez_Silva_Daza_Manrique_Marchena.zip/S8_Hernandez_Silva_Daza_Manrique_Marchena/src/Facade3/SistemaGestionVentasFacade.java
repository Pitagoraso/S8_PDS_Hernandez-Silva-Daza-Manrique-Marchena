package Facade3;

public class SistemaGestionVentasFacade {
    private Inventario inventario;
    private Pedidos pedidos;
    private Clientes clientes;

    public SistemaGestionVentasFacade() {
        this.inventario = new Inventario();
        this.pedidos = new Pedidos();
        this.clientes = new Clientes();
    }

    public void agregarProductoAlInventario(String producto) {
        inventario.agregarProducto(producto);
    }

    public void eliminarProductoDelInventario(String producto) {
        inventario.eliminarProducto(producto);
    }

    public void crearPedido(String producto) {
        pedidos.crearPedido(producto);
    }

    public void cancelarPedido(String producto) {
        pedidos.cancelarPedido(producto);
    }

    public void agregarCliente(String cliente) {
        clientes.agregarCliente(cliente);
    }

    public void eliminarCliente(String cliente) {
        clientes.eliminarCliente(cliente);
    }

    public void mostrarSistema() {
        inventario.mostrarInventario();
        pedidos.mostrarPedidos();
        clientes.mostrarClientes();
    }
}
