package Proxy4;

public class CuentaBancaria implements Banco {
    private double saldo;

    public CuentaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    @Override
    public void depositar(double monto) {
        saldo += monto;
        System.out.println("Deposito de: " + monto);
    }

    @Override
    public void retirar(double monto) {
        if (saldo >= monto) {
            saldo -= monto;
            System.out.println("Retiro de: " + monto);
        } else {
            System.out.println("Fondos insuficientes para retirar: " + monto);
        }
    }

    @Override
    public double getSaldo() {
        return saldo;
    }
}
