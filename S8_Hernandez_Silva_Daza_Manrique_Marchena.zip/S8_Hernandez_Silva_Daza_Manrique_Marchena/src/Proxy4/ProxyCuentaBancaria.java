package Proxy4;

public class ProxyCuentaBancaria implements Banco {
    private CuentaBancaria cuentaBancaria;

    public ProxyCuentaBancaria(double saldoInicial) {
        this.cuentaBancaria = new CuentaBancaria(saldoInicial);
    }

    @Override
    public void depositar(double monto) {
        iniciarTransaccion();
        try {
            cuentaBancaria.depositar(monto);
            commitTransaccion();
        } catch (Exception e) {
            rollbackTransaccion();
        }
    }

    @Override
    public void retirar(double monto) {
        iniciarTransaccion();
        try {
            cuentaBancaria.retirar(monto);
            commitTransaccion();
        } catch (Exception e) {
            rollbackTransaccion();
        }
    }

    @Override
    public double getSaldo() {
        return cuentaBancaria.getSaldo();
    }

    private void iniciarTransaccion() {
        System.out.println("Iniciando transaccion...");
    }

    private void commitTransaccion() {
        System.out.println("Transaccion completada.");
    }

    private void rollbackTransaccion() {
        System.out.println("Transaccion revertida.");
    }
}
