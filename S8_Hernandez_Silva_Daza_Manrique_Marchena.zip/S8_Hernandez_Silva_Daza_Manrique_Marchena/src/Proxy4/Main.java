package Proxy4;

public class Main {
    public static void main(String[] args) {
        Banco cuenta = new ProxyCuentaBancaria(1000.0);
        cuenta.depositar(500.0);  // Iniciando transacción... Depósito de: 500.0 Transacción completada.
        cuenta.retirar(200.0);    // Iniciando transacción... Retiro de: 200.0 Transacción completada.
        cuenta.retirar(1500.0);   // Iniciando transacción... Fondos insuficientes para retirar: 1500.0 Transacción completada.
        System.out.println("Saldo actual: " + cuenta.getSaldo());  // Saldo actual: 1300.0
    }
}
