package Proxy4;

public interface Banco {
    void depositar(double monto);
    void retirar(double monto);
    double getSaldo();
}
