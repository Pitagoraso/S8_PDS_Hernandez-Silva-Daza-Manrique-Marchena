package Proxy2;

public interface Recurso {
    void operacion();
}
