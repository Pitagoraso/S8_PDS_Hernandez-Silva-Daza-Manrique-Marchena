package Proxy2;

public class RecursoReal implements Recurso {
    @Override
    public void operacion() {
        System.out.println("Operacion realizada en el recurso real.");
    }
}
