package Proxy2;

public class ProxyAcceso implements Recurso {
    private Recurso recursoReal;
    private String usuario;
    private String contrasena;

    public ProxyAcceso(Recurso recursoReal, String usuario, String contrasena) {
        this.recursoReal = recursoReal;
        this.usuario = usuario;
        this.contrasena = contrasena;
    }

    @Override
    public void operacion() {
        if (autenticar()) {
            recursoReal.operacion();
        } else {
            System.out.println("Acceso denegado: credenciales incorrectas.");
        }
    }

    private boolean autenticar() {
        // Verificacion simple de credenciales (usuario: "admin", contrasena: "1234")
        return "admin".equals(usuario) && "1234".equals(contrasena);
    }
}
