package Proxy2;

public class Cliente {
    public static void main(String[] args) {
        Recurso recurso = new ProxyAcceso(new RecursoReal(), "admin", "1234");
        recurso.operacion(); // Operacion realizada en el recurso real.

        Recurso recursoInvalido = new ProxyAcceso(new RecursoReal(), "usuario", "incorrecto");
        recursoInvalido.operacion(); // Acceso denegado: credenciales incorrectas.
    }
}
