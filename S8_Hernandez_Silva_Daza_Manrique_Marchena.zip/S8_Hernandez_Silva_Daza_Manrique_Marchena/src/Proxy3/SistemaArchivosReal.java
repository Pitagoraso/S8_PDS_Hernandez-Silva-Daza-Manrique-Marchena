package Proxy3;

public class SistemaArchivosReal implements SistemaArchivos {
    @Override
    public void leerArchivo(String nombreArchivo) {
        System.out.println("Leyendo archivo: " + nombreArchivo);
        // Simulación de lectura del archivo
        System.out.println("Contenido del archivo " + nombreArchivo);
    }

    @Override
    public void escribirArchivo(String nombreArchivo, String contenido) {
        System.out.println("Escribiendo en el archivo: " + nombreArchivo);
        // Simulación de escritura del archivo
        System.out.println("Contenido escrito: " + contenido);
    }
}
