package Proxy3;

public class Cliente {
    public static void main(String[] args) {
        SistemaArchivos sistemaArchivosAdmin = new ProxySistemaArchivos("admin");
        sistemaArchivosAdmin.leerArchivo("documento.txt"); // Acceso permitido
        sistemaArchivosAdmin.escribirArchivo("documento.txt", "Contenido nuevo"); // Acceso permitido

        SistemaArchivos sistemaArchivosEditor = new ProxySistemaArchivos("editor");
        sistemaArchivosEditor.leerArchivo("documento.txt"); // Acceso permitido
        sistemaArchivosEditor.escribirArchivo("documento.txt", "Contenido editado"); // Acceso permitido

        SistemaArchivos sistemaArchivosLector = new ProxySistemaArchivos("lector");
        sistemaArchivosLector.leerArchivo("documento.txt"); // Acceso permitido
        sistemaArchivosLector.escribirArchivo("documento.txt", "Contenido no autorizado"); // Acceso denegado

        SistemaArchivos sistemaArchivosInvitado = new ProxySistemaArchivos("invitado");
        sistemaArchivosInvitado.leerArchivo("documento.txt"); // Acceso denegado
        sistemaArchivosInvitado.escribirArchivo("documento.txt", "Contenido no autorizado"); // Acceso denegado
    }
}
