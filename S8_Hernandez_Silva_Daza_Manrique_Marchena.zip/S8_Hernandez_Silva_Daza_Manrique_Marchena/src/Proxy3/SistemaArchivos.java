package Proxy3;

public interface SistemaArchivos {
    void leerArchivo(String nombreArchivo);
    void escribirArchivo(String nombreArchivo, String contenido);
}
