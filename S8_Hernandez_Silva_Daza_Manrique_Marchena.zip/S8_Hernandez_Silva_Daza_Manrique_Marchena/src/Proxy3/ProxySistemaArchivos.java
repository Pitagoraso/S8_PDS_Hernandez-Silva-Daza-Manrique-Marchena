package Proxy3;

public class ProxySistemaArchivos implements SistemaArchivos {
    private SistemaArchivosReal sistemaArchivosReal;
    private String usuario;
    private String rol;

    public ProxySistemaArchivos(String usuario) {
        this.usuario = usuario;
        this.rol = obtenerRol(usuario);
        this.sistemaArchivosReal = new SistemaArchivosReal();
    }

    @Override
    public void leerArchivo(String nombreArchivo) {
        if (puedeLeer()) {
            sistemaArchivosReal.leerArchivo(nombreArchivo);
        } else {
            System.out.println("Acceso denegado: El usuario " + usuario + " no tiene permisos para leer archivos.");
            System.out.println();
        }
    }

    @Override
    public void escribirArchivo(String nombreArchivo, String contenido) {
        if (puedeEscribir()) {
            sistemaArchivosReal.escribirArchivo(nombreArchivo, contenido);
        } else {
            System.out.println("Acceso denegado: El usuario " + usuario + " no tiene permisos para escribir archivos.");
            System.out.println();
        }
    }

    private boolean puedeLeer() {
        return "ADMIN".equals(rol) || "EDITOR".equals(rol) || "LECTOR".equals(rol);
    }

    private boolean puedeEscribir() {
        return "ADMIN".equals(rol) || "EDITOR".equals(rol);
    }

    private String obtenerRol(String usuario) {
        // Simulación de obtención de rol
        switch (usuario) {
            case "admin":
                return "ADMIN";
            case "editor":
                return "EDITOR";
            case "lector":
                return "LECTOR";
            default:
                return "INVITADO";
        }
    }
}
