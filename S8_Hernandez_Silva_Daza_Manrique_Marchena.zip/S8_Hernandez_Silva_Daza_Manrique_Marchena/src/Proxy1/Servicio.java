package Proxy1;

public interface Servicio {
    void realizar();
    void mostrarDetalles();
}
