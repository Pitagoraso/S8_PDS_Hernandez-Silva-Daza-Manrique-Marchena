package Proxy1;

public class SalaMusculacion implements Servicio {
    private String nombre;

    public SalaMusculacion() {
        this.nombre = "Sala de Musculacion";
    }

    @Override
    public void realizar() {
        System.out.println("Accediendo a " + nombre);
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Detalles de " + nombre);
    }
}
