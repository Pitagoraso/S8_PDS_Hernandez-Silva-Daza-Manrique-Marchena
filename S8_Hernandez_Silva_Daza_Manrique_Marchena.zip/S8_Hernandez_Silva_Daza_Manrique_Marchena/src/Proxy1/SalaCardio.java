package Proxy1;

public class SalaCardio implements Servicio {
    private String nombre;

    public SalaCardio() {
        this.nombre = "Sala de Cardio";
    }

    @Override
    public void realizar() {
        System.out.println("Accediendo a " + nombre);
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Detalles de " + nombre);
    }
}
