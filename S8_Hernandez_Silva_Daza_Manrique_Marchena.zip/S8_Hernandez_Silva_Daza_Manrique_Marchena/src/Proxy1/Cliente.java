package Proxy1;

public class Cliente {
    public static void main(String[] args) {
        // Miembro registrado
        Servicio proxyCardio = new ProxyServicio("Cardio", true);
        proxyCardio.mostrarDetalles();
        proxyCardio.realizar();

        // Usuario no registrado
        Servicio proxyMusculacion = new ProxyServicio("Musculacion", false);
        proxyMusculacion.mostrarDetalles();
        proxyMusculacion.realizar();
    }
}
