package Proxy1;

public class ProxyServicio implements Servicio {
    private Servicio servicioReal;
    private String tipoServicio;
    private boolean esMiembro;

    public ProxyServicio(String tipoServicio, boolean esMiembro) {
        this.tipoServicio = tipoServicio;
        this.esMiembro = esMiembro;
    }

    private void crearServicioReal() {
        if (servicioReal == null) {
            switch (tipoServicio) {
                case "Cardio":
                    servicioReal = new SalaCardio();
                    break;
                case "Musculacion":
                    servicioReal = new SalaMusculacion();
                    break;
                case "Entrenador":
                    servicioReal = new EntrenadorPersonal();
                    break;
                default:
                    throw new IllegalArgumentException("Tipo de servicio desconocido: " + tipoServicio);
            }
        }
    }

    @Override
    public void realizar() {
        if (esMiembro) {
            crearServicioReal();
            servicioReal.realizar();
        } else {
            System.out.println("Acceso denegado al servicio: " + tipoServicio);
        }
    }

    @Override
    public void mostrarDetalles() {
        if (esMiembro) {
            crearServicioReal();
            servicioReal.mostrarDetalles();
        } else {
            System.out.println("Acceso denegado a los detalles del servicio: " + tipoServicio);
        }
    }
}
