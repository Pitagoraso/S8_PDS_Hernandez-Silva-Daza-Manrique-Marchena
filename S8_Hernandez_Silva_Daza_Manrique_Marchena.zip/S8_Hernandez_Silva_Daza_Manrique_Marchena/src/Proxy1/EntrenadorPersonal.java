package Proxy1;

public class EntrenadorPersonal implements Servicio {
    private String nombre;

    public EntrenadorPersonal() {
        this.nombre = "Entrenador Personal";
    }

    @Override
    public void realizar() {
        System.out.println("Accediendo a " + nombre);
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Detalles de " + nombre);
    }
}
